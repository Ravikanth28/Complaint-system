"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const aws_sdk_1 = require("aws-sdk");
const generative_ai_1 = require("@google/generative-ai");
const s3 = new aws_sdk_1.S3();
const genAI = new generative_ai_1.GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');
const STRUCTURED_BUCKET = process.env.STRUCTURED_BUCKET_NAME || 'complaint-system-analysis-results';
const handler = async (event) => {
    try {
        const { query, complaintId } = JSON.parse(event.body || '{}');
        let context = "";
        if (complaintId) {
            const response = await s3.getObject({
                Bucket: STRUCTURED_BUCKET,
                Key: `analyzed/${complaintId}.json`
            }).promise();
            context = response.Body?.toString() || "";
        }
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        const prompt = `You are an Admin Assistant for the Complaint System.
    Context Data: ${context}
    User Query: ${query}
    
    Provide insights, response drafts, or escalate as needed.`;
        const result = await model.generateContent(prompt);
        const answer = result.response.text();
        return {
            statusCode: 200,
            headers: { 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({ answer })
        };
    }
    catch (error) {
        console.error('Chatbot error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal Server Error' })
        };
    }
};
exports.handler = handler;
