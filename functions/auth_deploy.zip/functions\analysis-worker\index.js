"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const aws_sdk_1 = require("aws-sdk");
const generative_ai_1 = require("@google/generative-ai");
const s3 = new aws_sdk_1.S3();
const genAI = new generative_ai_1.GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');
const STRUCTURED_BUCKET = process.env.STRUCTURED_BUCKET_NAME || 'complaint-system-analysis-results';
const handler = async (event) => {
    for (const record of event.Records) {
        const bucket = record.s3.bucket.name;
        const key = record.s3.object.key;
        // Fetch processed complaint
        const response = await s3.getObject({ Bucket: bucket, Key: key }).promise();
        const complaint = JSON.parse(response.Body?.toString() || '{}');
        // GenAI Analysis
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        const prompt = `Analyze this complaint:
    Title: ${complaint.title}
    Description: ${complaint.description}
    
    Provide output in JSON:
    {
      "summary": "short summary",
      "category": "one of [IT Support, Accounts, Hostel, Academic, Transport, Maintenance]",
      "urgency": "LOW, MEDIUM, or HIGH",
      "entities": ["list of key entities"]
    }`;
        const result = await model.generateContent(prompt);
        const aiOutput = JSON.parse(result.response.text());
        const enrichedComplaint = {
            ...complaint,
            analysis: aiOutput,
            status: 'ANALYZED'
        };
        // Store in structured bucket
        await s3.putObject({
            Bucket: STRUCTURED_BUCKET,
            Key: `analyzed/${complaint.complaintId}.json`,
            Body: JSON.stringify(enrichedComplaint),
            ContentType: 'application/json'
        }).promise();
    }
};
exports.handler = handler;
