"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const aws_sdk_1 = require("aws-sdk");
const uuid_1 = require("uuid");
const s3 = new aws_sdk_1.S3();
const RAW_BUCKET = process.env.RAW_BUCKET_NAME || 'complaint-system-raw-data';
const handler = async (event) => {
    try {
        const body = JSON.parse(event.body || '{}');
        const complaintId = (0, uuid_1.v4)();
        const timestamp = new Date().toISOString();
        const complaintData = {
            complaintId,
            ...body,
            timestamp,
            status: 'RAW'
        };
        await s3.putObject({
            Bucket: RAW_BUCKET,
            Key: `complaints/${complaintId}.json`,
            Body: JSON.stringify(complaintData),
            ContentType: 'application/json'
        }).promise();
        return {
            statusCode: 201,
            headers: { 'Access-Control-Allow-Origin': '*' },
            body: JSON.stringify({
                message: 'Complaint submitted successfully',
                complaintId
            })
        };
    }
    catch (error) {
        console.error('Error submitting complaint:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal Server Error' })
        };
    }
};
exports.handler = handler;
