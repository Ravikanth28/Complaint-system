"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const aws_sdk_1 = require("aws-sdk");
const generative_ai_1 = require("@google/generative-ai");
const utils_1 = require("../../shared/utils");
const s3 = new aws_sdk_1.S3();
const genAI = new generative_ai_1.GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');
const handler = async (event) => {
    for (const record of event.Records) {
        const bucket = record.s3.bucket.name;
        const key = record.s3.object.key;
        const response = await s3.getObject({ Bucket: bucket, Key: key }).promise();
        const complaint = JSON.parse(response.Body?.toString() || '{}');
        // Semantic Triage Reasoning
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });
        const prompt = `Act as a Semantic Triage Agent. Based on the complaint and its initial analysis, determine the best department.
    
    Complaint: ${complaint.description}
    Initial Category: ${complaint.analysis.category}
    Initial Urgency: ${complaint.analysis.urgency}
    
    Available Departments: IT Support, Accounts, Hostel Office, Academic Office, Transport Office, Maintenance.
    
    Provide reasoning and a confidence score.
    Output JSON:
    {
      "department": "Department Name",
      "reasoning": "Explain why based on hidden intent",
      "confidence": 0.95
    }`;
        const result = await model.generateContent(prompt);
        const triageResult = (0, utils_1.parseAIJson)(result.response.text());
        const triagedComplaint = {
            ...complaint,
            triage: triageResult,
            status: 'TRIAGED'
        };
        // Update complaint record in S3
        await s3.putObject({
            Bucket: bucket,
            Key: key,
            Body: JSON.stringify(triagedComplaint),
            ContentType: 'application/json'
        }).promise();
    }
};
exports.handler = handler;
